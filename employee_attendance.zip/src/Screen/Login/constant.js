export const initialFormValue = { email: "", password: "", role: "" };

export const validateForm = (obj) => {
  let errors = {};
  if (obj?.email?.length === 0) errors.email = "Email id required";
  if (obj?.password?.length === 0) errors.password = " password is required";
  if (obj?.role?.length === 0) errors.role = " Role  is required";
  return errors;
};

export const DropDownData = [
  { label: "Employee", value: "emp" },
  { label: "Admin", value: "admin" },
];
