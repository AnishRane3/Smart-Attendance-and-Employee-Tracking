import { FontAwesome } from "@expo/vector-icons";
import { Pressable, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const AuthForm = ({ children, heading, onPress, bottomText1, bottomText2 }) => {
  return (
    <SafeAreaView className={`bg-white flex-1 justify-center items-center`}>
      <ScrollView
        contentContainerStyle={{
          justifyContent: "center",
          alignItems: "center",
          flex: 1,
        }}
      >
        <FontAwesome name="users" size={65} color="rgb(192 38 211)" />
        <Text className={`text-xl pb-5 font-bold`}>Employees Attendance</Text>
        <View
          className={`w-11/12 bg-zinc-100 px-2 py-8 justify-center items-center border border-gray-200 rounded-lg`}
        >
          <Text className={`font-bold text-2xl`}>{heading}</Text>
          <View className={`w-full`}>{children}</View>
          {/* <Pressable onPress={onPress}>
            <View className={`flex-row pt-5 gap-2`}>
              <Text>{bottomText1}</Text>
              <Text className={`text-blue-500`}>{bottomText2}</Text>
            </View>
          </Pressable> */}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default AuthForm;
